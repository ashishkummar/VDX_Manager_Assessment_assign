import { makeStyles } from '@material-ui/core/styles';

export const CSSGoalsFeedbackModal = makeStyles({
    root:{
        position:'absolute',
        marginTop:82,
        width:window.innerWidth-520,
        height:window.innerHeight-400,
        background:'white'
    },
    textArea:{
        marginTop:10,
        height:window.innerHeight-450,
        resize:'none'
    },
    header:{

    }
})